      var revapi1, tpj;
      jQuery(function() {
         tpj = jQuery;
         if (tpj("#rev_slider_1_1").revolution == undefined) {
            revslider_showDoubleJqueryError("#rev_slider_1_1")
         } else {
            revapi1 = tpj("#rev_slider_1_1").show().revolution({
               jsFileLocation: "js/",
               sliderLayout: "fullwidth",
               visibilityLevels: "1240,1024,778,480",
               gridwidth: "1300,1024,778,480",
               gridheight: "900,709,539,333",
               spinner: "spinner0",
               editorheight: "900,709,539,333",
               responsiveLevels: "1240,1024,778,480",
               disableProgressBar: "on",
               navigation: {
                  onHoverStop: false,
                  arrows: {
                     enable: true,
                     tmp: "<div class=\"tp-arr-allwrapper\"> <div class=\"tp-arr-imgholder\"></div></div>",
                     style: "hades",
                     hide_onmobile: true,
                     hide_under: "1499px",
                     left: {
                        h_offset: 0
                     },
                     right: {
                        h_offset: 0
                     }
                  },
                  bullets: {
                     enable: true,
                     tmp: "",
                     style: "hermes",
                     hide_over: "1499px"
                  }
               },
               fallbacks: {
                  allowHTML5AutoPlayOnAndroid: true
               },
            })
         }
      });



      var revapi4,
         tpj;
      jQuery(function() {
         tpj = jQuery;
         if (tpj("#rev_slider_4_1").revolution == undefined) {
            revslider_showDoubleJqueryError("#rev_slider_4_1");
         } else {
            revapi4 = tpj("#rev_slider_4_1").show().revolution({
               jsFileLocation: "js/",
               sliderLayout: "fullwidth",
               visibilityLevels: "1240,1024,778,480",
               gridwidth: "1300,1024,778,480",
               gridheight: "900,709,539,333",
               spinner: "spinner0",
               editorheight: "900,709,539,333",
               responsiveLevels: "1240,1024,778,480",
               disableProgressBar: "on",
               navigation: {
                  onHoverStop: false,
                  bullets: {
                     enable: true,
                     tmp: "<span class=\"tp-bullet-inner\"></span>",
                     style: "uranus"
                  }
               },
               fallbacks: {
                  allowHTML5AutoPlayOnAndroid: true
               },
            });
         }

      });



      var revapi6,
         tpj;
      jQuery(function() {
         tpj = jQuery;
         if (tpj("#rev_slider_6_1").revolution == undefined) {
            revslider_showDoubleJqueryError("#rev_slider_6_1");
         } else {
            revapi6 = tpj("#rev_slider_6_1").show().revolution({
               jsFileLocation: "js/",
               sliderLayout: "fullwidth",
               visibilityLevels: "1240,1024,778,480",
               gridwidth: "1300,1024,778,480",
               gridheight: "900,709,539,333",
               spinner: "spinner0",
               editorheight: "900,709,539,333",
               responsiveLevels: "1240,1024,778,480",
               disableProgressBar: "on",
               navigation: {
                  onHoverStop: false,
                  arrows: {
                     enable: true,
                     tmp: "<div class=\"tp-arr-allwrapper\"> <div class=\"tp-arr-imgholder\"></div></div>",
                     style: "hades",
                     hide_onmobile: true,
                     hide_under: "1499px",
                     left: {
                        h_offset: 0
                     },
                     right: {
                        h_offset: 0
                     }
                  },
                  bullets: {
                     enable: true,
                     tmp: "",
                     style: "hermes",
                     hide_over: "1499px"
                  }
               },
               fallbacks: {
                  allowHTML5AutoPlayOnAndroid: true
               },
            });
         }

      });
      var   revapi9,
                  tpj;
               jQuery(function() {
                  tpj = jQuery;
                  if(tpj("#rev_slider_9_1").revolution == undefined){
                     revslider_showDoubleJqueryError("#rev_slider_9_1");
                  }else{
                     revapi9 = tpj("#rev_slider_9_1").show().revolution({
                        jsFileLocation:"js/",
                        sliderLayout:"fullwidth",
                        visibilityLevels:"1240,1024,778,480",
                        gridwidth:"1300,1024,778,480",
                        gridheight:"900,709,539,333",
                        spinner:"spinner0",
                        editorheight:"900,709,539,333",
                        responsiveLevels:"1240,1024,778,480",
                        disableProgressBar:"on",
                        navigation: {
                           onHoverStop:false,
                           arrows: {
                              enable:true,
                              tmp:"<div class=\"tp-title-wrap\">     <div class=\"tp-arr-imgholder\"></div>    <div class=\"tp-arr-img-over\"></div>  <span class=\"tp-arr-titleholder\">{{title}}</span> </div>",
                              style:"erinyen",
                              hide_onmobile:true,
                              hide_under:"1499px",
                              left: {
                                 h_offset:0
                              },
                              right: {
                                 h_offset:0
                              }
                           },
                           bullets: {
                              enable:true,
                              tmp:"",
                              style:"hermes",
                              hide_over:"1499px"
                           }
                        },
                        fallbacks: {
                           allowHTML5AutoPlayOnAndroid:true
                        },
                     });
                  }
                  
               });

               var   revapi10,
                  tpj;
               jQuery(function() {
                  tpj = jQuery;
                  if(tpj("#rev_slider_10_1").revolution == undefined){
                     revslider_showDoubleJqueryError("#rev_slider_10_1");
                  }else{
                     revapi10 = tpj("#rev_slider_10_1").show().revolution({
                        jsFileLocation:"js/",
                        sliderLayout:"fullwidth",
                        visibilityLevels:"1240,1024,778,480",
                        gridwidth:"1300,1024,778,480",
                        gridheight:"900,709,539,333",
                        spinner:"spinner0",
                        editorheight:"900,709,539,333",
                        responsiveLevels:"1240,1024,778,480",
                        disableProgressBar:"on",
                        navigation: {
                           onHoverStop:false,
                           bullets: {
                              enable:true,
                              tmp:"<span class=\"tp-bullet-inner\"></span>",
                              style:"uranus"
                           }
                        },
                        fallbacks: {
                           allowHTML5AutoPlayOnAndroid:true
                        },
                     });
                  }
                  
               });

               var   revapi12,
                  tpj;
               jQuery(function() {
                  tpj = jQuery;
                  if(tpj("#rev_slider_12_1").revolution == undefined){
                     revslider_showDoubleJqueryError("#rev_slider_12_1");
                  }else{
                     revapi12 = tpj("#rev_slider_12_1").show().revolution({
                        jsFileLocation:"js/",
                        sliderLayout:"fullwidth",
                        visibilityLevels:"1240,1024,778,480",
                        gridwidth:"1300,1024,778,480",
                        gridheight:"900,709,539,333",
                        spinner:"spinner0",
                        editorheight:"900,709,539,333",
                        responsiveLevels:"1240,1024,778,480",
                        disableProgressBar:"on",
                        navigation: {
                           onHoverStop:false,
                           arrows: {
                              enable:true,
                              tmp:"<div class=\"tp-arr-allwrapper\"> <div class=\"tp-arr-imgholder\"></div></div>",
                              style:"hades",
                              hide_onmobile:true,
                              hide_under:"1499px",
                              left: {
                                 h_offset:0
                              },
                              right: {
                                 h_offset:0
                              }
                           },
                           bullets: {
                              enable:true,
                              tmp:"",
                              style:"hermes",
                              hide_over:"1499px"
                           }
                        },
                        fallbacks: {
                           allowHTML5AutoPlayOnAndroid:true
                        },
                     });
                  }
                  
               });

               var   revapi17,
                  tpj;
               jQuery(function() {
                  tpj = jQuery;
                  if(tpj("#rev_slider_17_1").revolution == undefined){
                     revslider_showDoubleJqueryError("#rev_slider_17_1");
                  }else{
                     revapi17 = tpj("#rev_slider_17_1").show().revolution({
                        jsFileLocation:"js/",
                        sliderLayout:"fullwidth",
                        visibilityLevels:"1240,1024,778,480",
                        gridwidth:"1300,1024,778,480",
                        gridheight:"900,709,539,333",
                        spinner:"spinner0",
                        editorheight:"900,709,539,333",
                        responsiveLevels:"1240,1024,778,480",
                        disableProgressBar:"on",
                        navigation: {
                           onHoverStop:false,
                           arrows: {
                              enable:true,
                              tmp:"<div class=\"tp-arr-allwrapper\"> <div class=\"tp-arr-imgholder\"></div></div>",
                              style:"hades",
                              hide_onmobile:true,
                              hide_under:"1499px",
                              left: {
                                 h_offset:0
                              },
                              right: {
                                 h_offset:0
                              }
                           },
                           bullets: {
                              enable:true,
                              tmp:"",
                              style:"hermes",
                              hide_over:"1499px"
                           }
                        },
                        fallbacks: {
                           allowHTML5AutoPlayOnAndroid:true
                        },
                     });
                  }
                  
               });