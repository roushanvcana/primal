<div class="slider_padding">
<div id="banner-slider" class="owl-carousel owl-theme">
	<div class="item">
		<div class="slider_img">
			<img src="assets/img/banner-slider/slider-banner.jpg" alt="banner"/>
		</div>
	</div>
<div class="item">
		<div class="slider_img">
			<img src="assets/img/banner-slider/slider-banner.jpg" alt="banner"/>
		</div>
	</div>
</div>
	</div>