<div class="slider-area">
	<div class="slider-active owl-carousel nav-style-1">
		<div class="single-slider slider-height-1 bg-paleturquoise">
			<img class="animated" src="assets/img/slider/slider-banner.jpg" alt="">
		</div>
		<div class="single-slider slider-height-1 bg-paleturquoise">
			<img class="animated" src="assets/img/slider/slider-banner.jpg" alt="">
		</div>
	</div>
</div>